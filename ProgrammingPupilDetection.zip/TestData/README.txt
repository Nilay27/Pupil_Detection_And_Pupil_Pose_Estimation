TASK 1
Two test images are provided:
Real/01.jpg
Real/02.jpg

TASK 2
The camera matrix is in CameraMatrix.txt.
Three synthetic data are provided:

DATA1
Synthetic/01.png                -- pupil image
Synthetic/01_3DSphereParam.txt  -- 3D sphere parameter (x, y, z, R) 

DATA2
Synthetic/02.png
Synthetic/02_3DSphereParam.txt

DATA3
Synthetic/03.png
Synthetic/03_3DSphereParam.txt